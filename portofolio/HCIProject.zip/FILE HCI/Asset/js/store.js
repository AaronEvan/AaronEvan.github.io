function play(){
    alert("You can buy this item only at concert")
}