<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//for user
Route::group(['middleware'=>'guest'], function(){
    Route::get('/login', 'UserController@loginPage');
    Route::get('/register', 'UserController@registerPage');
});

//for guest
Route::group(['middleware' =>'myauth'], function(){
    Route::get('/product/{name}', 'ProductController@showDetail');
    Route::get('/cart', 'CartController@show');
    Route::get('/history/new', 'TransactionController@createTransaction');
    Route::get('/history','TransactionController@showHistory');
    Route::get('/transactiondetails/{id}','TransactionController@showDetail');
    
});

//for admin
Route::group(['middleware' =>'myadmin'], function(){
    Route::get('/admin', 'AdminController@index');
    Route::get('/admin/category', 'AdminController@category');
    Route::get('/admin/category/{category}', 'AdminController@pickCategory');
    Route::get('/admin/addcategory', 'AdminController@addCategoryPage');
    Route::get('/admin/product', 'AdminController@product');
    Route::get('/admin/addproduct', 'AdminController@addProductPage');
    Route::get('/admin/user', 'AdminController@userPage');
});

//all user
Route::group(['middleware' => 'authhome'], function(){
    Route::get('/', 'ProductController@index');
    Route::get('/search', 'ProductController@search');
});


Route::post('/admin/addcategory', 'AdminController@addCategory');
Route::post('/admin/addproduct', 'AdminController@addProduct');

Route::delete('/admin/user/delete/{id}', 'AdminController@userDelete');
Route::delete('/admin/delete/{id}', 'AdminController@productDelete');

Route::post('/login', 'UserController@loginCheck');
Route::post('/register', 'UserController@registerCheck');
Route::get('/logout', 'UserController@logout');

Route::delete('/delete/{id}', 'CartController@deleteItem');
Route::post('/addcart/{id}', 'CartController@add');