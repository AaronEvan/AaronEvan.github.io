<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public function category(){
        return $this->belongsTo(Category::class);
    }

    public function detail_transaction(){
        return $this->belongsTo(DetailTransaction::class);
    }

    public function cart(){
        return $this->belongsTo(Cart::class);
    }

    protected $fillable = ['productname', 'category_id', 'productdescription', 'productprice', 'productimage'];
    protected $table = 'products';
}
