<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable 
{
    protected $table = 'users';
    protected $fillable = ['username', 'useremail', 'password', 'userrole'];

    public function header_transaction(){
        return $this->hasMany(HeaderTransaction::class);
    }

    public function cart(){
        return $this->hasOne(Cart::class);
    }

}
