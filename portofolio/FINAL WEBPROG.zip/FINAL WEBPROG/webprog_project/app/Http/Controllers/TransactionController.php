<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cart;
use App\Product;
use App\HeaderTransaction;
use App\DetailTransaction;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class TransactionController extends Controller
{
    public function createTransaction(){
        $auth = Auth::check();
        $user_id = Auth::id();

        $cart = Cart::where('user_id','=', $user_id)->get();
        $date = Carbon::now("Asia/Bangkok");

        $head_trans = HeaderTransaction::create([
            'user_id' => $user_id,
            'transactiondate' => $date
        ]);
        
        
        foreach($cart as $c){
            DetailTransaction::create([
                'transaction_id' => $head_trans->id,
                'product_id' => $c->product_id, 
                'quantity' => $c->quantity
            ]);
            $c->delete();
        }
        
        $carts = Cart::join('products','carts.product_id','=','products.id')
                        ->where('carts.user_id','=', Auth::user()->id)->get();

        $trans = HeaderTransaction::where('user_id','=',$user_id)->get();
        return view('history', compact('auth','trans', 'carts'));
    }

    public function showHistory(){
        $auth = Auth::check();
        $user_id = Auth::id();
        
        $carts = Cart::join('products','carts.product_id','=','products.id')
                        ->where('carts.user_id','=', Auth::user()->id)->get();

        $trans = HeaderTransaction::where('user_id','=',$user_id)->get();
        return view('history', compact('auth','trans', 'carts'));
    }

    public function showDetail($id){
        $auth = Auth::check();
        $user_id = Auth::id();

        $details = DetailTransaction::join('products','detail_transactions.product_id','=','products.id')
                        ->where('detail_transactions.transaction_id','=',$id)->get();

                        
        $carts = Cart::join('products','carts.product_id','=','products.id')
        ->where('carts.user_id','=', Auth::user()->id)->get();

        return view('detailtransaction', compact('details', 'auth', 'carts'));
    }
}
