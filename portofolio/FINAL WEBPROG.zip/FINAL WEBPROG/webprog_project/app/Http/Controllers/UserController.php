<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;

class UserController extends Controller
{
    public function loginPage(){
        $auth = Auth::check();
        return view('login', compact('auth'));
    }

    public function registerPage(){
        $auth = Auth::check();
        return view('register', compact('auth'));
    }

    public function logout(){
        Auth::logout();
        return redirect('/login');
    }

    public function registerCheck(Request $request){
        $request->validate([
            'UserName' => 'required|unique:Users',
            'UserEmail' => 'required|unique:Users',
            'UserPassword' => 'required|same:ConfirmPassword|min:5',
            'ConfirmPassword' => 'required|same:UserPassword|min:5'
        ]);

        //untuk masuk ke database
       $user =  User::create([
            'username' => $request->UserName,
            'useremail' => $request->UserEmail,
            'password' => bcrypt($request->UserPassword),
            'userrole' => '1'
        ]);

        Auth::login($user);

        return redirect('/')->with('success', 'Register Berhasil');
    }

    public function loginCheck(Request $request){
        $request->validate([
            'useremail' => 'required',
            'password' => 'required|min:5'
        ]);

        $credentials = $request->only('useremail', 'password');

        $rem_me = $request->remember ? true : false;

        //remember_me check
        if($rem_me != null){
            Cookie::queue('my_email', $request->useremail,120);
            Cookie::queue('my_pass', $request->password,120);
        }else{
            Cookie::queue(Cookie::forget('my_email'));
            Cookie::queue(Cookie::forget('my_pass'));
        }
        
        if(Auth::attempt($credentials)){
            $user = User::where('useremail', '=', $request->useremail)->first();

            if($user->userrole == 1){
                return redirect('/')->with('success', 'Login Berhasil');
            }else{
                return redirect('/admin');
            }

        }else{
            return redirect('/login')->with('error', 'Login Failed');
        }
    }
}
