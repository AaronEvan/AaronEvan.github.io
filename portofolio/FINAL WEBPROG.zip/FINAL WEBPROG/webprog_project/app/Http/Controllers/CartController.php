<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cart;
use App\Product;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function add($id, Request $request){
        $request->validate([
            'quantity' => 'required|gt:0'
        ]);
        
        $user_id = Auth::id();
        
        $cart = Cart::where('user_id','=',$user_id)
                    ->where('product_id','=',$id)
                    ->first();
        
        //ketemu
        if($cart != null){
            Cart::where('user_id','=',$user_id)
                ->where('product_id','=',$id)
                ->update([
                    'quantity' => $request->quantity,
                ]);
            
            $product = Product::where('id','=',$id)->first();
            return redirect('/')->with('success', 'Add to Cart Success');
            // return dd($id);
        }
        else{
            Cart::create([
                'user_id' => $user_id,
                'product_id' => $id,
                'quantity' => $request->quantity
            ]);
            $product = Product::where('id','=',$id)->first();
            return redirect('/')->with('success', 'Add to Cart Success');
            // return dd($id);
        }
    }

    public function show(){
        $auth = Auth::check();
        $user_id = Auth::id();

        $carts = Cart::join('products','carts.product_id','=','products.id')
                        ->where('carts.user_id','=',$user_id)->get();
        
        // return dd($cart);
        $total = 0;
        foreach($carts as $sc){
            $total += ($sc->productprice * $sc->quantity);
        }
        
        return view('cart', compact('carts', 'auth', 'total'));
    }

    public function deleteItem($id) {
        $cart = Cart::where('product_id','=',$id)->first();
        $cart->delete();
        
        return redirect('/cart')->with('success', 'Delete Success!');
    }
}
