<?php

namespace App\Http\Controllers;

use App\Cart;
use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    public function index(){
        $auth = Auth::check();
        $products = Product::paginate(3);
        if($auth){
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', Auth::user()->id)->get();
        }else{
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', '0')->get();
        }
        return view('index', compact('products', 'auth', 'carts'));
    }
    
    public function showDetail($name){
        $auth = Auth::check();
        $product = Product::where('productname', '=', $name)->first();
        if($auth){
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', Auth::user()->id)->get();
        }else{
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', '0')->get();
        }
        // $carts = Cart::join('products','carts.product_id','=','products.id')
        // ->where('carts.user_id','=', Auth::user()->id)->get();

        return view('detail', compact('product', 'auth', 'carts'));
    }
    
    public function search(Request $request){
        $auth = Auth::check();
        $products = Product::where('productname', 'like', "%$request->search%")->paginate(3);
        $products->appends(['search'=>$request->search]);
        if($auth){
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', Auth::user()->id)->get();
        }else{
            $carts = Cart::join('products','carts.product_id','=','products.id')
            ->where('carts.user_id','=', '0')->get();
        }
        // $carts = Cart::join('products','carts.product_id','=','products.id')
        //                 ->where('carts.user_id','=', Auth::user()->id)->get();

        return view('search', compact('products', 'auth', 'carts'));
    }
}
