<?php

namespace App\Http\Controllers;

use App\Category;
use App\Product;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index(){
        $auth = Auth::check();

        return view('admin.index', compact('auth'));
    }

    public function category(){
        $auth = Auth::check();
        $categories = Category::all();
        $products = null;
        // return dd($category);
        return view('admin.category', compact('categories', 'auth', 'products'));
    }

    public function pickCategory($category){
        $products = Category::join('products','products.category_id','=','categories.id')
        ->where('categories.category','=',$category)->get();
        // return dd($products);
        return redirect('/admin/category')->with(['products'=>$products]);
    }

    public function addCategoryPage(){
        $auth = Auth::check();
        return view('admin.addcategory', compact('auth'));
    }

    public function addCategory(Request $request){
        $request->validate([
            'category' => 'required|unique:category'
        ]);
        
        Category::create([
            'category' => $request->category
        ]);

        return redirect('/admin/addcategory')->with('success', 'Add Category Success');
    }

    public function product(){
        $products = Product::all();
        return view('admin.product', compact('products'));
    }

    public function productDelete($id){
        $product = Product::where('id','=',$id)->first();
        $product->delete();

        return redirect('/admin/product')->with('success', 'Delete Success!');
    }

    public function addProductPage(){
        $auth = Auth::check();
        $categories = Category::all();
        return view('admin.addproduct', compact('auth', 'categories'));
    }

    public function addProduct(Request $request){
        
        $request->validate([
            'productname' => 'required|unique:products',
            'category' => 'required',
            'description' => 'required',
            'productprice' => 'required|gt:100',
            'productimage' => 'required|max:10000|mimes:png,jpg,jpeg'
        ]);
        
        $image_path = $request->file('productimage')->store('images', 'public');

        $image_path = substr($image_path, 7);

        Product::create([
            'productname' => $request->productname,
            'category_id' => $request->category,
            'productdescription' => $request->description,         
            'productprice' => $request->productprice,
            'productimage' => $image_path
        ]);
        
        return redirect('/admin/addproduct')->with('success', 'Add Product Success');
    }

    public function userPage(){
        $auth = Auth::check();
        $users = User::where('userrole','=', '1')->get();

        return view('admin.user', compact('auth', 'users'));
    }

    public function userDelete($id){
        $user = User::where('id','=',$id)->first();
        $user->delete();

        return redirect('/admin/user')->with('success', 'Delete Success!');
    }


}