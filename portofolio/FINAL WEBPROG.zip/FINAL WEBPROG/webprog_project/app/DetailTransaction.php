<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailTransaction extends Model
{
    protected $fillable = ['transaction_id', 'product_id', 'quantity'];

    public function header_transaction(){
        return $this->belongsTo(HeaderTransaction::class);
    }

    public function product(){
        return $this->hasMany(Product::class);
    }

    protected $table = 'detail_transactions';
}