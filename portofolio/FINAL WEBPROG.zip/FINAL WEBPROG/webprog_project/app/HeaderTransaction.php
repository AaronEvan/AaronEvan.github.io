<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeaderTransaction extends Model
{
    protected $fillable = ['user_id', 'transactiondate'];
    protected $dates = ['transactiondate'];

    public function getFromDateAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    public function detail_transaction(){
        return $this->hasMany(DetailTransaction::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    protected $table = 'header_transactions';
}
