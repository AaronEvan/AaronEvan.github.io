<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

use Faker\Factory as Faker;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        
        DB::table('users')->insert([
            'username' => $faker->name,
            'useremail' => $faker->unique()->email,
            'password' => bcrypt('123'),
            'userrole' => '1'
        ]);

        DB::table('users')->insert([
            'username' => $faker->name,
            'useremail' => $faker->unique()->email,
            'password' => bcrypt('123'),
            'userrole' => '2'
        ]);

        for($i = 1; $i <= 3; $i++){
            DB::table('users')->insert([
                'username' => $faker->name,
                'useremail' => $faker->unique()->email,
                'password' => bcrypt('123'),
                'userrole' => $faker->numberBetween(1,2)
            ]);
        }
    }
}
