<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
            [
                'category_id' => '3',
                'productname' =>'Huawei P40 Pro',
                'productdescription'=>'Huawei P40 Pro 8/128 GB',
                'productimage'=>'huaweip40.jpg',
                'productprice'=>'12999000'
            ],
            [
                'category_id' => '2',
                'productname' =>'Ghost of Tsushima',
                'productdescription'=>'Ghost of Tsushima is an action-adventure game, it follows Jin Sakai, a samurai on a quest to protect Tsushima Island during the first Mongol invasion of Japan.',
                'productimage'=>'ghosttsushima.jpg',
                'productprice'=>'719000'
            ],
            [
                'category_id' => '2',
                'productname' =>'The Last of Us Part II',
                'productdescription'=>'The Last of Us Part II is a 2020 action-adventure game developed by Naughty Dog and published by Sony Interactive Entertainment.',
                'productimage'=>'tlou.jpg',
                'productprice'=>'425000'
            ],
            [
                'category_id' => '3',
                'productname' =>'Galaxy Note 20 Ultra',
                'productdescription'=>'Samsung Galaxy Note 20 Ultra 12/128 GB',
                'productimage'=>'note20.jpg',
                'productprice'=>'11999000'
            ],
            [
                'category_id' => '1',
                'productname' =>'Samsung UHD 4K Smart TV 55 inch',
                'productdescription'=>'Samsung RU7100U UHD 4K Smart TV 55 inch',
                'productimage'=>'samsungtv.jpg',
                'productprice'=>'10999000'
            ],
            [
                'category_id' => '1',
                'productname' =>'Sony UHD 4K Smart TV 75 inch',
                'productdescription'=>'Sony X750H UHD 4K Smart TV 75 inch',
                'productimage'=>'sonytv.jpg',
                'productprice'=>'12999000'
            ]   
        ]);
    }
}
