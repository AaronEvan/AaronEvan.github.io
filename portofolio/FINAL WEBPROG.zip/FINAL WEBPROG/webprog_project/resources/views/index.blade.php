@extends('layout/master')

@section('title', 'Home')

@section('search')
  @include('layout/searchbar')
@endsection

@section('content')
    @if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
    @endif
    <div class="container mt-5">
      <div class="row justify-content-md-center">
          @foreach ($products as $product)
              <div class="col-4">
                  <div class="card">
                      <div class="card-body">
                          <div class="wrapper">
                              <img src="{{ asset('storage/images/'.$product->productimage) }}" class="card-img-top text-center" style="height:380px;">
                          </div>
                          <div class="container">
                              <br>
                              <h5 class="text-primary" style="min-height: 48px">{{$product->productname}}</h5>
                              <p class="card-text">IDR. {{$product->productprice}}</p>
                              <a class="btn btn-success"
                              href="
                              @if($auth)
                                  /product/{{$product->productname}}  
                              @else
                                  /login  
                              @endif">Product Detail</a>
                          </div>
                      </div>
                  </div>
              </div>
          @endforeach
      </div>
      
    </div>
    <div class="container mx-auto mt-3">
        {{$products->links()}}
    </div>
@endsection