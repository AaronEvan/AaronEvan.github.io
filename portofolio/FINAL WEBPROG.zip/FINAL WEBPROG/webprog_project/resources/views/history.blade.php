@extends('layout/master')

@section('title', 'History')

@section('search')
    @include('layout/searchbar')
@endsection

@section('content')

    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">My Transaction</h2>
    </div>

    @if($trans->count() == 0)
      <h2 class="font-weight-bold text-center">There is no transaction!</h2>
    @else
        <div class="card mt-3">
            <div class="card-body">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th style="background-color: #46c864; color: white;" >Transaction History</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($trans as $h)
                        <tr>
                            <td>
                                <a href="/transactiondetails/{{$h->id}}" style="color: black;">{{$h->transactiondate}}</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
    
    
@endsection