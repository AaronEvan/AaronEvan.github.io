@extends('layout/master')

@section('title', 'Detail')

@section('search')
    @include('layout/searchbar')
@endsection

@section('content')
    <div class="container pt-4 py-3">
        <h1 class="font-weight-bold text-center">Product Detail</h1>
    </div>
    @if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
    @endif

    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="{{asset('storage/images/'.$product->productimage)}}" style="height: 350px; width: 300px" alt="">
            </div>
            <div class="col px-3">
                <h3 class="font-weight-bold">{{$product->productname}}<hr class="linehead my-0"></h3>
                <p>Price : 
                    <a>IDR. {{$product->productprice}}<hr class="linehead my-0"></a>
                </p>
                <p class="text-justify">Description : {{$product->productdescription}}</p>
                <div class="wrapper">
                    
                </div>
                <a class="btn btn-success" id="show" style="color: #fff">Add Cart</a>
                <form action="/addcart/{{$product->id}}" method="post" id="forms" style="display: none">
                    @csrf
                    <a>Quantity</a><input type="number" id="quantity" name="quantity"><br>
                    @error('quantity')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                    <button class="btn btn-success" style="color: #fff" type="submit">Add Cart</button>
                    
                </form>
            </div>
        </div>
    </div>
@endsection

@section('code')
$(document).ready(function(){
    $("#show").click(function(){
        $("#forms").show();
        $("#show").hide();
    });
});
@endsection