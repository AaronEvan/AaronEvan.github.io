@extends('layout/master')

@section('title', 'Login')

@section('login', 'active')

@section('content')
<div class="container w-50 mt-4 rounded-lg bg-light" style="padding: 0;">
    @if ($message = Session::get('error'))
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
    @endif
    <div class="card text-center">
        <div class="card-header text-left">
          Login
        </div>
        <form class="mx-auto mt-3"  method="post" action="/login">
            @csrf
            <div class="form-group row justify-content-md-center">
                <label for="useremail" class="px-0 text-right col-sm-4 col-form-label">E-Mail Address</label>
                <div class="col-sm-7">
                    <input type="email" class="form-control @error('useremail') is-invalid @enderror" id="useremail" name="useremail" value="{{Cookie::get('my_email')}}">
                </div>
                @error('useremail')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group row justify-content-md-center">
                <label for="password" class="px-0 text-right col-sm-4 col-form-label">Password</label>
                <div class="col-sm-7">
                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" value="{{Cookie::get('my_pass')}}">
                </div>
                @error('password')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group row justify-content-md-center">
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" id="autoSizingCheck" name="remember">
                    <label class="form-check-label" for="autoSizingCheck">
                        Remember me
                    </label>
                </div>
            </div>
            <div class="form-group row justify-content-md-center">
                <button type="submit" class="btn btn-primary w-auto">Login</button>
                    <a href="" class="text-primary my-2 mx-2">Forgot Your Password?</a>
            </div>
        </form>
    </div>
</div>
@endsection