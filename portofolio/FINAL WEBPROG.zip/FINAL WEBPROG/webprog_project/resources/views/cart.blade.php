@extends('layout/master')

@section('title', 'Cart')

@section('search')
    @include('layout/searchbar')
@endsection

@section('content')
    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">My Cart</h2>
    </div>
    @if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @foreach($carts as $c)
    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="{{asset('storage/images/'.$c->productimage)}}" style="height: 200px; width: 150px" alt="">
            </div>
                <div class="col px-3">
                    <h3 class="font-weight-bold">{{$c->productname}}<hr class="linehead my-0"></h3>
                    <p>Price : 
                        <a>IDR. {{$c->productprice * $c->quantity}}<hr class="linehead my-0"></a>
                    </p>
                    <p>Quantity: 
                        <a>{{$c->quantity}}</a>
                    </p>
                    <form action="/delete/{{$c->id}}" method="post" class="d-inline">
                        {{ method_field('delete') }}
                        @csrf
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    <a class="btn btn-success"  style="color: #fff" href="/product/{{$c->productname}}">Edit</a>
                </div>
        </div>
    </div>
    <br>
    @endforeach

    @if($carts->count() == 0)
      <h1 class="font-weight-bold text-center">There is no product added!</h1>
    @else
      <h1 class="font-weight-bold text-center">Total : IDR. {{$total}}</h1>
      
      <a class="btn btn-danger"  style="color: #fff; float:right;" href="/history/new">Checkout</a>
    @endif
    
@endsection