@extends('layout/master')

@section('title', 'Transaction Detail')

@section('search')
    @include('layout/searchbar')
@endsection

@section('content')

    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">Detail Transaction</h2>
    </div>

    @foreach($details as $d)
    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="{{asset('storage/images/'.$d->productimage)}}" style="height: 200px; width: 150px" alt="">
            </div>
                <div class="col px-3">
                    <h3 class="font-weight-bold">{{$d->productname}}<hr class="linehead my-0"></h3>
                    <p>Quantity: 
                        <a>{{$d->quantity}}</a>
                    </p>
                    <p>Price : 
                        <a>IDR. {{$d->productprice * $d->quantity}}<hr class="linehead my-0"></a>
                    </p>
                </div>
        </div>
    </div>
    <br>
    @endforeach
    
@endsection