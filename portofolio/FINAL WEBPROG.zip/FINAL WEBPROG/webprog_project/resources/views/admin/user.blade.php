@extends('admin.layout.master')

@section('title', 'User')

@section('content')
@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
@endif
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center mb-5">User</h3>
    <table class="table">
        <thead>
        <tr>
            <th class="text-center" scope="col">User Id</th>
            <th class="text-center" scope="col">Username</th>
            <th class="text-center" scope="col">Useremail</th>
            <th class="text-center" scope="col">User Role</th>
            <th class="text-center" scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($users as $i)
                <tr>
                    <td class="text-center">{{$i->id}}</td>
                    <td class="text-center">{{$i->username}}</td>
                    <td class="text-center">{{$i->useremail}}</td>
                    <td class="text-center">User</td>
                    <td class="text-center">
                        <form action="/admin/user/delete/{{$i->id}}" method="post" class="d-inline">
                            {{method_field('delete')}}
                            @csrf
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection