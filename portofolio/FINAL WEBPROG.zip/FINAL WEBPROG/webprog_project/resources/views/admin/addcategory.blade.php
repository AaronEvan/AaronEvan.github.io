@extends('admin.layout.master')

@section('title', 'Add Category')

@section('content')
<div class="container py-4 my-5 border-primary shadow rounded bg-light text-center">
    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong>{{ $message }}</strong>
        </div>
    @endif
    <h4>Name</h4>
    <form action="/admin/addcategory" method="post">
        @csrf
        <input type="text" class="form-control @error('category') is-invalid @enderror" id="category" name="category" placeholder="Category Name">
        <button type="submit" class="mt-3 btn btn-success w-auto text-center">Add Category</button>
    </form>
</div>
@endsection