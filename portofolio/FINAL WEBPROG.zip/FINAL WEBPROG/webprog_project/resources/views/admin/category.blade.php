@extends('admin.layout.master')

@section('title', 'Category')

@section('content')
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center">Category</h3>
    <table class="table">
        <thead>
        </thead>
        <tbody>
            @foreach ($categories as $i)
                <tr>
                    <td class="text-center">
                        <a href="/admin/category/{{$i->category}}">{{$i->category}}</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

@if ($products = Session::get('products'))
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center">Product</h3>
    <table class="table">
        <thead>
        <tr>
            <th class="text-center" scope="col">Product Id</th>
            <th class="text-center" scope="col">Product Image</th>
            <th class="text-center" scope="col">Product Name</th>
            <th class="text-center" scope="col">Product Price</th>
            <th class="text-center" scope="col">Product Description</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($products as $i)
                <tr>
                    <td class="text-center">{{$i->id}}</td>
                    <td class="text-center"><img src="{{asset('storage/images/'.$i->productimage)}}" alt="" style="height:150px;"></td>
                    <td class="text-center">{{$i->productname}}</td>
                    <td class="text-center">{{$i->productprice}}</td>
                    <td class="text-center">{{$i->productdescription}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endif

@endsection