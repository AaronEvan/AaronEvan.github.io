@extends('admin.layout.master')

@section('title', 'Admin')

@section('content')
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <div class="row">
        <div class="col  text-center">
            <h1>Admin</h1>
        </div>
    </div>
</div>
@endsection