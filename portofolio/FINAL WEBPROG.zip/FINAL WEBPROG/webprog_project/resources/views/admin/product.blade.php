@extends('admin.layout.master')

@section('title', 'Product')

@section('content')
@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong>{{ $message }}</strong>
    </div>
@endif
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center">Product</h3>
    <table class="table">
        <thead>
        <tr>
            <th class="text-center" scope="col">Product Id</th>
            <th class="text-center" scope="col">Product Image</th>
            <th class="text-center" scope="col">Product Name</th>
            <th class="text-center" scope="col">Product Category</th>
            <th class="text-center" scope="col">Product Price</th>
            <th class="text-center" scope="col">Product Description</th>
            <th class="text-center" scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($products as $i)
                <tr>
                    <td class="text-center">{{$i->id}}</td>
                    <td class="text-center"><img src="{{asset('storage/images/'.$i->productimage)}}" alt="" style="height:150px;"></td>
                    <td class="text-center">{{$i->productname}}</td>
                    <td class="text-center">{{$i->category->category}}</td>
                    <td class="text-center">{{$i->productprice}}</td>
                    <td class="text-center">{{$i->productdescription}}</td>
                    <td class="text-center">
                        <form action="/admin/delete/{{$i->id}}" method="post" class="d-inline">
                            {{method_field('delete')}}
                            @csrf
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection