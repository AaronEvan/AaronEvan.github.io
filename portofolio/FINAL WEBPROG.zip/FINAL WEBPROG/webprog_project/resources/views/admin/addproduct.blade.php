@extends('admin.layout.master')

@section('title', 'Add Product')

@section('content')
<div class="container py-4 my-5 border-primary shadow rounded bg-light text-center">
    @if ($message = Session::get('success'))
        <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong>{{ $message }}</strong>
        </div>
    @endif
    <h2>Add Product</h2>
    <form action="/admin/addproduct" method="post" enctype="multipart/form-data">
        @csrf
        <h5 class="text-left mt-4">Name</h5>
        <input type="text" class="form-control @error('productname') is-invalid @enderror" id="productname" placeholder="Product Name" name="productname">

        <h5 class="text-left mt-4">Category</h5>
        <div class="form-group">
            <select class="form-control @error('category') is-invalid @enderror" id="category" name="category">
                @foreach ($categories as $i)
                    <option value="{{$loop->iteration}}">{{$i->category}}</option>
                @endforeach
            </select>
        </div>

        <h5 class="text-left mt-4">Description</h5>
        <input type="text" class="form-control @error('description') is-invalid @enderror" id="description" name="description" placeholder="Product Description">
        
        <h5 class="text-left mt-4">Price</h5>
        <input type="number" class="form-control @error('productprice') is-invalid @enderror" id="productprice" name="productprice" placeholder="Product Price">

        <h5 class="text-left mt-4">Choose File</h5>
        <div class="form-group mx-auto">
            <input type="file" class="form-control-file" id="productimage" name="productimage">
        </div>

        <button type="submit" class="mt-3 btn btn-success w-auto text-center">Add Product</button>
    </form>
</div>
@endsection