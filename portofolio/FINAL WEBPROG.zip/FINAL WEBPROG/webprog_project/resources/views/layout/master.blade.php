<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <script src="{{ asset('bootstrap/js/jquery.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/popper.min.js') }}"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.js') }}"></script>
</head>
<body style="background-color: #ebedee;">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container ">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" style="color: #46c864; font-weight: bold;" href="/">$okopedia</a>
        <div class="wrapper w-100">
          @yield('search')
        </div>
        <ul class="navbar-nav mt-2 mt-lg-0">
          @if($auth)
            <li class="nav-item mx-1">
            <a class="btn btn-success" href="/cart" role="button">Cart<span class="m-0 ml-2 p-0 bg-white text-dark d-inline">{{$carts->count()}}</span>
              </a>
            </li>
            <li class="nav-item mx-1">
              <a class="btn btn-success" href="/history" role="button">History</a>
            </li>
            <li class="nav-item">
              <div class="dropdown show">
                <a class="nav-link my-2 my-sm-0 dropdown-toggle active" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  {{Auth::user()->username}}
                </a>
                <div class="container">
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                  <a class="dropdown-item" href="/logout">Log Out</a>
                </div>
              </div>
              </div>
            </li>
          @else
            <li class="nav-item">
              <a class="nav-link @yield('login')" href="/login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link @yield('register')" href="/register">Register</a>
            </li>
          @endif
        </ul>
      </div>
    </div>
  </nav>
  <div class="container">
      @yield('content')
  </div>
  <footer class="bg-light mt-5">
    @include('layout.footer')
  </footer>
</body>
  <script>
    @yield('code')
  </script>
</html>