<div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="/">$okopedia</a>
</div>