<form class="form-inline w-100" action="/search">
    @csrf
    <input class="form-control ml-auto mr-4" style="width: 82%" name="search" id="search" type="search" placeholder="Search" aria-label="Search">
    {{-- <div class="wrapper ml-auto"> --}}
    <button class="btn btn-outline-success ml-2" type="submit">Search</button>
    {{-- </div> --}}
</form>