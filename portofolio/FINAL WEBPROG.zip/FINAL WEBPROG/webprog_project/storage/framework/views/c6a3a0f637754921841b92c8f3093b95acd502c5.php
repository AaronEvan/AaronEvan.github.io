

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('search'); ?>
  <?php echo $__env->make('layout/search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>
    <div class="container mt-5">
      <div class="card-deck">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
          <div class="card-body">
            <div class="wrapper">
              <img src="<?php echo e(asset('/image/'.$product->productimage)); ?>" class="card-img-top text-center">
            </div>
            <div class="container">
              <h5 class="text-primary"><?php echo e($product->productname); ?></h5>
              <p class="card-text">IDR. <?php echo e($product->productprice); ?></p>
              <a class="btn btn-success" 
                href="
                <?php if($auth): ?>
                  /product/<?php echo e($product->productname); ?>  
                <?php else: ?>
                  /login  
                <?php endif; ?>">Product Detail</a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div >
        <?php echo e($products->links()); ?>

      </div> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\WebProg Lab Project\old 2\resources\views/index.blade.php ENDPATH**/ ?>