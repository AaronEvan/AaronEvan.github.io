<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
    <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand" style="font-weight: bold;" href="/admin">Admin</a>
            <ul class="navbar-nav mt-2 mt-lg-0">
                <li class="nav-item mx-1">
                    <div class="dropdown show">
                        <a class="nav-link my-2 my-sm-0 dropdown-toggle " href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Product
                        </a>
                        <div class="container">
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="/admin/addproduct">Add Product</a>
                                <a class="dropdown-item" href="/admin/product">Show Product</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item mx-1">
                    <div class="dropdown show">
                        <a class="nav-link my-2 my-sm-0 dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Category
                        </a>
                        <div class="container">
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="/admin/addcategory">Add Category</a>
                                <a class="dropdown-item" href="/admin/category">Show Category</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item mx-1">
                    <div class="dropdown show">
                        <a class="nav-link my-2 my-sm-0 dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            User
                        </a>
                        <div class="container">
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="/admin/user">Show USer</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            <div class="wrapper w-100">
              <?php echo $__env->yieldContent('search'); ?>
            </div>
            <ul class="navbar-nav mt-2 mt-lg-0">
                <li class="nav-item">
                    <div class="dropdown show">
                        <a class="nav-link my-2 my-sm-0 dropdown-toggle active" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->username); ?>

                        </a>
                        <div class="container">
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="/logout">Log Out</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="container">
          <?php echo $__env->yieldContent('content'); ?>
      </div>
</body>
</html><?php /**PATH C:\Users\arone\Desktop\webprog_project\webprog_project\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>