<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
    <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>"></script>
</head>
<body style="background-color: #ebedee;">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container ">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" style="color: #46c864; font-weight: bold;" href="/">$okopedia</a>
        <div class="wrapper w-100">
          <?php echo $__env->yieldContent('search'); ?>
        </div>
        <ul class="navbar-nav mt-2 mt-lg-0">
          <?php if($auth): ?>
            <li class="nav-item mx-1">
            <a class="btn btn-success" href="/cart" role="button">Cart<span class="m-0 ml-2 p-0 bg-white text-dark d-inline"><?php echo e($carts->count()); ?></span>
              </a>
            </li>
            <li class="nav-item mx-1">
              <a class="btn btn-success" href="/history" role="button">History</a>
            </li>
            <li class="nav-item">
              <div class="dropdown show">
                <a class="nav-link my-2 my-sm-0 dropdown-toggle active" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(Auth::user()->username); ?>

                </a>
                <div class="container">
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                  <a class="dropdown-item" href="/logout">Log Out</a>
                </div>
              </div>
              </div>
            </li>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('login'); ?>" href="/login">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('register'); ?>" href="/register">Register</a>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container">
      <?php echo $__env->yieldContent('content'); ?>
  </div>
  <footer class="bg-light mt-5">
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </footer>
</body>
  <script>
    <?php echo $__env->yieldContent('code'); ?>
  </script>
</html><?php /**PATH C:\Users\arone\Desktop\FINAL WEBPROG\webprog_project\resources\views/layout/master.blade.php ENDPATH**/ ?>