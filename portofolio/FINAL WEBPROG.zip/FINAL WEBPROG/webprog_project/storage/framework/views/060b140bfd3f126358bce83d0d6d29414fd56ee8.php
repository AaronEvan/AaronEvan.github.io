

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center mb-5">User</h3>
    <table class="table">
        <thead>
        <tr>
            <th class="text-center" scope="col">User Id</th>
            <th class="text-center" scope="col">Username</th>
            <th class="text-center" scope="col">Useremail</th>
            <th class="text-center" scope="col">User Role</th>
            <th class="text-center" scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($i->id); ?></td>
                    <td class="text-center"><?php echo e($i->username); ?></td>
                    <td class="text-center"><?php echo e($i->useremail); ?></td>
                    <td class="text-center">User</td>
                    <td class="text-center">
                        <form action="/admin/user/delete/<?php echo e($i->id); ?>" method="post" class="d-inline">
                            <?php echo e(method_field('delete')); ?>

                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\webprog_project\webprog_project\resources\views/admin/user.blade.php ENDPATH**/ ?>