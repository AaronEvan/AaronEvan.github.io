<form class="form-inline w-100" action="/search">
    <?php echo csrf_field(); ?>
    <input class="form-control ml-auto mr-4" style="width: 82%" name="search" id="search" type="search" placeholder="Search" aria-label="Search">
    
    <button class="btn btn-outline-success ml-2" type="submit">Search</button>
    
</form><?php /**PATH C:\Users\arone\Desktop\FINAL WEBPROG\webprog_project\resources\views/layout/searchbar.blade.php ENDPATH**/ ?>