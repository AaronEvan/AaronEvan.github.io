

<?php $__env->startSection('title', 'Add Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 my-5 border-primary shadow rounded bg-light text-center">
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>	
                <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>
    <h4>Name</h4>
    <form action="/admin/addcategory" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category" name="category" placeholder="Category Name">
        <button type="submit" class="mt-3 btn btn-success w-auto text-center">Add Category</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\Laravel Projects\search done\resources\views/admin/addcategory.blade.php ENDPATH**/ ?>