

<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('search'); ?>
  <?php echo $__env->make('layout/searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-4 py-3 mb-0">
        <h2 class="font-weight-bold text-center mb-0">Your Search Result</h2>
    </div>
    <?php if($products->count() == 0): ?>
        <div class="container pt-4 py-3">
            <h2 class="font-weight-bold text-center">No Product Found.</h2>
        </div>
    <?php else: ?>
        <div class="container my-3">
            <div class="row justify-content-md-center">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="wrapper">
                                    <img src="<?php echo e(asset('storage/images/'.$product->productimage)); ?>" class="card-img-top text-center" style="height:380px;">
                                </div>
                                <div class="container">
                                    <br>
                                    <h5 class="text-primary" style="min-height: 48px"><?php echo e($product->productname); ?></h5>
                                    <p class="card-text">IDR. <?php echo e($product->productprice); ?></p>
                                    <a class="btn btn-success"
                                    href="
                                    <?php if($auth): ?>
                                        /product/<?php echo e($product->productname); ?>  
                                    <?php else: ?>
                                        /login  
                                    <?php endif; ?>">Product Detail</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-3">
              <?php echo e($products->links()); ?>

            </div> 
        </div>    
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\FINAL WEBPROG\webprog_project\resources\views/search.blade.php ENDPATH**/ ?>