<form class="form-inline my-2 my-lg-0" method="POST" action="/search">
    <?php echo csrf_field(); ?>
    <input class="form-control mr-sm-2 ml-auto" name="search" id="search" style="width: 81%;" type="search" placeholder="Search" aria-label="Search">
    <div class="wrapper ml-auto">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </div>
</form><?php /**PATH C:\Users\arone\Desktop\laravel\resources\views/layout/search.blade.php ENDPATH**/ ?>