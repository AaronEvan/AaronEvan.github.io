<div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="/">$okopedia</a>
</div><?php /**PATH C:\Users\arone\Desktop\FINAL WEBPROG\webprog_project\resources\views/layout/footer.blade.php ENDPATH**/ ?>