

<?php $__env->startSection('title', 'Transaction Detail'); ?>

<?php $__env->startSection('search'); ?>
    <?php echo $__env->make('layout/searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">Detail Transaction</h2>
    </div>

    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="<?php echo e(asset('storage/images/'.$d->productimage)); ?>" style="height: 200px; width: 150px" alt="">
            </div>
                <div class="col px-3">
                    <h3 class="font-weight-bold"><?php echo e($d->productname); ?><hr class="linehead my-0"></h3>
                    <p>Quantity: 
                        <a><?php echo e($d->quantity); ?></a>
                    </p>
                    <p>Price : 
                        <a>IDR. <?php echo e($d->productprice * $d->quantity); ?><hr class="linehead my-0"></a>
                    </p>
                </div>
        </div>
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\Laravel Projects\search done\resources\views/detailtransaction.blade.php ENDPATH**/ ?>