

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <div class="row">
        <div class="col  text-center">
            <h1>Admin</h1>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\webprog_project\webprog_project\resources\views/admin/index.blade.php ENDPATH**/ ?>