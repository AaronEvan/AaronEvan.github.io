

<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('register', 'active'); ?>

<?php $__env->startSection('content'); ?>
<div class="container w-50 mt-4 rounded-lg bg-light" style="padding: 0;">
    <div class="card text-center">
        <div class="card-header text-left">
          Register
        </div>
        <form class="mx-auto mt-3" method="post" action="/register">
            <?php echo csrf_field(); ?>
            <div class="form-group row justify-content-md-center">
                <label for="UserName" class="pl-0 text-right col-sm-5 col-form-label pr-0">Name</label>
                <div class="col-sm-7">
                    <input type="text" class="form-control <?php $__errorArgs = ['UserName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="UserName" name="UserName">
                </div>
                <?php $__errorArgs = ['UserName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group row justify-content-md-center">
                <label for="UserEmail" class="pl-0 text-right col-sm-5 col-form-label pr-0">E-Mail Address</label>
                <div class="col-sm-7">
                    <input type="email" class="form-control <?php $__errorArgs = ['UserEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="UserEmail" name="UserEmail">
                </div>
                <?php $__errorArgs = ['UserEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group row justify-content-md-center">
                <label for="UserPassword" class="pl-0 text-right col-sm-5 col-form-label pr-0">Password</label>
                <div class="col-sm-7">
                    <input type="password" class="form-control <?php $__errorArgs = ['UserPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="UserPassword" name="UserPassword">
                </div>
                <?php $__errorArgs = ['UserPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group row justify-content-md-center">
                <label for="ConfirmPassword" class="pl-0 text-right col-sm-5 col-form-label pr-0">Confirm Password</label>
                <div class="col-sm-7">
                    <input type="password" class="form-control <?php $__errorArgs = ['ConfirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ConfPassword" name="ConfirmPassword">
                </div>
                <?php $__errorArgs = ['ConfirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group row justify-content-md-center">
                <button type="submit" class="btn btn-primary w-auto">Register</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\Web Programming\Project WebProg\FINAL WEBPROG\webprog_project\resources\views/register.blade.php ENDPATH**/ ?>