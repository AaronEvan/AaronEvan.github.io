

<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
<div class="container py-4 my-5 border-primary shadow rounded bg-light">
    <h3 class="text-center">Product</h3>
    <table class="table">
        <thead>
        <tr>
            <th class="text-center" scope="col">Product Id</th>
            <th class="text-center" scope="col">Product Image</th>
            <th class="text-center" scope="col">Product Name</th>
            <th class="text-center" scope="col">Product Category</th>
            <th class="text-center" scope="col">Product Price</th>
            <th class="text-center" scope="col">Product Description</th>
            <th class="text-center" scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($i->id); ?></td>
                    <td class="text-center"><img src="<?php echo e(asset('storage/images/'.$i->productimage)); ?>" alt=""></td>
                    <td class="text-center"><?php echo e($i->productname); ?></td>
                    <td class="text-center"><?php echo e($i->category->category); ?></td>
                    <td class="text-center"><?php echo e($i->productprice); ?></td>
                    <td class="text-center"><?php echo e($i->productdescription); ?></td>
                    <td class="text-center">
                        <form action="/admin/delete/<?php echo e($i->id); ?>" method="post" class="d-inline">
                            <?php echo e(method_field('delete')); ?>

                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\search done\resources\views/admin/product.blade.php ENDPATH**/ ?>