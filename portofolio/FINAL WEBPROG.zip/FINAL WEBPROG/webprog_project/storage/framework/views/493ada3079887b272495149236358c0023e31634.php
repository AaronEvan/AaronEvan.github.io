

<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('search'); ?>
    <?php echo $__env->make('layout/searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-4 py-3">
        <h1 class="font-weight-bold text-center">Product Detail</h1>
    </div>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="<?php echo e(asset('storage/images/'.$product->productimage)); ?>" style="height: 350px; width: 300px" alt="">
            </div>
            <div class="col px-3">
                <h3 class="font-weight-bold"><?php echo e($product->productname); ?><hr class="linehead my-0"></h3>
                <p>Price : 
                    <a>IDR. <?php echo e($product->productprice); ?><hr class="linehead my-0"></a>
                </p>
                <p class="text-justify">Description : <?php echo e($product->productdescription); ?></p>
                <div class="wrapper">
                    
                </div>
                <a class="btn btn-success" id="show" style="color: #fff">Add Cart</a>
                <form action="/addcart/<?php echo e($product->id); ?>" method="post" id="forms" style="display: none">
                    <?php echo csrf_field(); ?>
                    <a>Quantity</a><input type="number" id="quantity" name="quantity"><br>
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button class="btn btn-success" style="color: #fff" type="submit">Add Cart</button>
                    
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('code'); ?>
$(document).ready(function(){
    $("#show").click(function(){
        $("#forms").show();
        $("#show").hide();
    });
});
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\search done\resources\views/detail.blade.php ENDPATH**/ ?>