

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('search'); ?>
    <?php echo $__env->make('layout/searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">My Cart</h2>
    </div>
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block">
      <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="<?php echo e(asset('storage/images/'.$c->productimage)); ?>" style="height: 200px; width: 150px" alt="">
            </div>
                <div class="col px-3">
                    <h3 class="font-weight-bold"><?php echo e($c->productname); ?><hr class="linehead my-0"></h3>
                    <p>Price : 
                        <a>IDR. <?php echo e($c->productprice * $c->quantity); ?><hr class="linehead my-0"></a>
                    </p>
                    <p>Quantity: 
                        <a><?php echo e($c->quantity); ?></a>
                    </p>
                    <form action="/delete/<?php echo e($c->id); ?>" method="post" class="d-inline">
                        <?php echo e(method_field('delete')); ?>

                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    <a class="btn btn-success"  style="color: #fff" href="/product/<?php echo e($c->productname); ?>">Edit</a>
                </div>
        </div>
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($cart->count() == 0): ?>
      <h1 class="font-weight-bold text-center">There is no product added!</h1>
    <?php else: ?>
      <h1 class="font-weight-bold text-center">Total : IDR. <?php echo e($total); ?></h1>
      
      <a class="btn btn-danger"  style="color: #fff; float:right;" href="/history/new">Checkout</a>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\webprog_project\webprog_project\resources\views/cart.blade.php ENDPATH**/ ?>