

<?php $__env->startSection('title', 'History'); ?>

<?php $__env->startSection('search'); ?>
    <?php echo $__env->make('layout/searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container pt-4 py-3">
        <h2 class="font-weight-bold text-center">My Transaction</h2>
    </div>

    <?php if($trans->count() == 0): ?>
      <h2 class="font-weight-bold text-center">There is no transaction!</h2>
    <?php else: ?>
        <div class="card mt-3">
            <div class="card-body">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th style="background-color: #46c864; color: white;" >Transaction History</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="/transactiondetails/<?php echo e($h->id); ?>" style="color: black;"><?php echo e($h->transactiondate); ?></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\laravel\resources\views/history.blade.php ENDPATH**/ ?>