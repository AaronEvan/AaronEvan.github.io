

<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pt-4 py-3">
        <h1 class="font-weight-bold text-center">Product Detail</h1>
    </div>
    <div class="container py-5 border-primary shadow rounded bg-light">
        <div class="row">
            <div class="col px-3 text-center">
                <img class="align-middle p-auto" src="<?php echo e(asset('image/'.$product->productimage)); ?>" style="height: 250px; width: 200px" alt="">
            </div>
            <div class="col px-3">
                <h3 class="font-weight-bold"><?php echo e($product->productname); ?><hr class="linehead my-0"></h3>
                <p>Price : 
                    <a>IDR. <?php echo e($product->productprice); ?><hr class="linehead my-0"></a>
                </p>
                <p class="text-justify">Description : <?php echo e($product->productdescription); ?></p>
                <div class="wrapper">
                    
                </div>
                <a class="btn btn-success" href="">Add Cart</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
$(document).ready(function(){
    $("#hide").click(function(){
      $("p").hide();
    });
    $("#show").click(function(){
      $("p").show();
    });
  });
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arone\Desktop\WebProg Lab Project\old 2\resources\views/detail.blade.php ENDPATH**/ ?>