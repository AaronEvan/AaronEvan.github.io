<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
    <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>"></script>
</head>
<body style="background-color: #ebedee;">
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" style="color: #46c864; font-weight: bold;" href="/">$okopedia</a>
        <form class="form-inline mx-auto my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
        <ul class="navbar-nav mt-2 mt-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="#">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Register</a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
  <div class="container">
      
  </div> 
</body>
</html><?php /**PATH C:\Users\arone\Desktop\Project Webprog Sokopedia11\Project Webprog Sokopedia\laravel\resources\views/layout/aster.blade.php ENDPATH**/ ?>