package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;

public class MemberprofileActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double i = 0;
	
	private LinearLayout linear1;
	private LinearLayout listbody;
	private ImageView backbtn;
	private TextView textview1;
	private TextView textview27;
	private TextView textview29;
	private TextView emailtxt;
	private TextView textview30;
	private TextView idtxt;
	private Button changebtn;
	private Button logout;
	
	private Intent pindah = new Intent();
	private FirebaseAuth memberauth;
	private OnCompleteListener<AuthResult> _memberauth_create_user_listener;
	private OnCompleteListener<AuthResult> _memberauth_sign_in_listener;
	private OnCompleteListener<Void> _memberauth_reset_password_listener;
	private TimerTask tikmer;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.memberprofile);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		listbody = (LinearLayout) findViewById(R.id.listbody);
		backbtn = (ImageView) findViewById(R.id.backbtn);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview27 = (TextView) findViewById(R.id.textview27);
		textview29 = (TextView) findViewById(R.id.textview29);
		emailtxt = (TextView) findViewById(R.id.emailtxt);
		textview30 = (TextView) findViewById(R.id.textview30);
		idtxt = (TextView) findViewById(R.id.idtxt);
		changebtn = (Button) findViewById(R.id.changebtn);
		logout = (Button) findViewById(R.id.logout);
		memberauth = FirebaseAuth.getInstance();
		
		backbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HomememberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		changebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (i == 1) {
					SketchwareUtil.showMessage(getApplicationContext(), "You just send change password vertification at email. Please check your email.");
				}
				else {
					memberauth.sendPasswordResetEmail(FirebaseAuth.getInstance().getCurrentUser().getEmail()).addOnCompleteListener(_memberauth_reset_password_listener);
					tikmer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									i++;
								}
							});
						}
					};
					_timer.schedule(tikmer, (int)(86400));
				}
			}
		});
		
		logout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), MainActivity.class);
				FirebaseAuth.getInstance().signOut();
				startActivity(pindah);
				finish();
			}
		});
		
		_memberauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		emailtxt.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
		idtxt.setText(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(5)).toUpperCase());
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		pindah.setClass(getApplicationContext(), HomememberActivity.class);
		startActivity(pindah);
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
