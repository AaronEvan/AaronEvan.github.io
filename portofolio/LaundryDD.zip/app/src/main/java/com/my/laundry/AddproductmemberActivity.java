package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.view.View;

public class AddproductmemberActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> datauser = new HashMap<>();
	private String userid = "";
	private double totalprice = 0;
	private double temp = 0;
	private HashMap<String, Object> pricetemp = new HashMap<>();
	private double i = 0;
	
	private ArrayList<HashMap<String, Object>> listmapuser = new ArrayList<>();
	private ArrayList<String> totalkilo = new ArrayList<>();
	private ArrayList<String> jenis = new ArrayList<>();
	private ArrayList<String> key = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> price = new ArrayList<>();
	
	private LinearLayout fulllinear;
	private LinearLayout linear10;
	private LinearLayout linear5;
	private LinearLayout linear24;
	private LinearLayout navbar;
	private ImageView imageview6;
	private TextView textview21;
	private ImageView imageview7;
	private LinearLayout linear6;
	private LinearLayout linear23;
	private LinearLayout linear8;
	private TextView txtitems;
	private LinearLayout linear16;
	private TextView txt1;
	private TextView txt2;
	private TextView txt3;
	private TextView textview3;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private TextView kiloanminus;
	private TextView qtykilo;
	private TextView kiloanplus;
	private TextView jasminus;
	private TextView qtyjas;
	private TextView jasplus;
	private TextView bedmin;
	private TextView qtybed;
	private TextView bedplus;
	private TextView textview4;
	private LinearLayout linear21;
	private TextView kiloanprice;
	private TextView jasprice;
	private TextView bedprice;
	private TextView textview29;
	private EditText receivertxt;
	private TextView textview28;
	private EditText alamattxt;
	private TextView total;
	private Button savebtn;
	private LinearLayout homebtn;
	private LinearLayout buybtn;
	private LinearLayout historybtn;
	private LinearLayout helpbtn;
	private ImageView imageview2;
	private TextView textview2;
	private ImageView imageview3;
	private TextView textview24;
	private ImageView imageview4;
	private TextView textview27;
	private ImageView imageview5;
	private TextView textview25;
	
	private Intent pindah = new Intent();
	private AlertDialog.Builder dialog;
	private FirebaseAuth userauth;
	private OnCompleteListener<AuthResult> _userauth_create_user_listener;
	private OnCompleteListener<AuthResult> _userauth_sign_in_listener;
	private OnCompleteListener<Void> _userauth_reset_password_listener;
	private DatabaseReference memberdata = _firebase.getReference("memberdata");
	private ChildEventListener _memberdata_child_listener;
	private Calendar time = Calendar.getInstance();
	private DatabaseReference pegawaiprice = _firebase.getReference("pegawaiprice");
	private ChildEventListener _pegawaiprice_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.addproductmember);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		fulllinear = (LinearLayout) findViewById(R.id.fulllinear);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		navbar = (LinearLayout) findViewById(R.id.navbar);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview21 = (TextView) findViewById(R.id.textview21);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		txtitems = (TextView) findViewById(R.id.txtitems);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		txt1 = (TextView) findViewById(R.id.txt1);
		txt2 = (TextView) findViewById(R.id.txt2);
		txt3 = (TextView) findViewById(R.id.txt3);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		kiloanminus = (TextView) findViewById(R.id.kiloanminus);
		qtykilo = (TextView) findViewById(R.id.qtykilo);
		kiloanplus = (TextView) findViewById(R.id.kiloanplus);
		jasminus = (TextView) findViewById(R.id.jasminus);
		qtyjas = (TextView) findViewById(R.id.qtyjas);
		jasplus = (TextView) findViewById(R.id.jasplus);
		bedmin = (TextView) findViewById(R.id.bedmin);
		qtybed = (TextView) findViewById(R.id.qtybed);
		bedplus = (TextView) findViewById(R.id.bedplus);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		kiloanprice = (TextView) findViewById(R.id.kiloanprice);
		jasprice = (TextView) findViewById(R.id.jasprice);
		bedprice = (TextView) findViewById(R.id.bedprice);
		textview29 = (TextView) findViewById(R.id.textview29);
		receivertxt = (EditText) findViewById(R.id.receivertxt);
		textview28 = (TextView) findViewById(R.id.textview28);
		alamattxt = (EditText) findViewById(R.id.alamattxt);
		total = (TextView) findViewById(R.id.total);
		savebtn = (Button) findViewById(R.id.savebtn);
		homebtn = (LinearLayout) findViewById(R.id.homebtn);
		buybtn = (LinearLayout) findViewById(R.id.buybtn);
		historybtn = (LinearLayout) findViewById(R.id.historybtn);
		helpbtn = (LinearLayout) findViewById(R.id.helpbtn);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview24 = (TextView) findViewById(R.id.textview24);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview27 = (TextView) findViewById(R.id.textview27);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview25 = (TextView) findViewById(R.id.textview25);
		dialog = new AlertDialog.Builder(this);
		userauth = FirebaseAuth.getInstance();
		
		kiloanminus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 == Double.parseDouble(qtykilo.getText().toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "Qty cannot less than 0");
				}
				else {
					temp = Double.parseDouble(qtykilo.getText().toString());
					temp--;
					datauser.put("qtykiloan", String.valueOf((long)(temp)));
					qtykilo.setText(String.valueOf((long)(temp)));
					temp = Double.parseDouble(datauser.get("pricekiloan1").toString()) * temp;
					kiloanprice.setText(String.valueOf((long)(temp)));
					datauser.put("pricekiloan", String.valueOf((long)(temp)));
					datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
					total.setText("Rp. ".concat(datauser.get("totprice").toString()));
				}
			}
		});
		
		kiloanplus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				temp = Double.parseDouble(qtykilo.getText().toString());
				temp++;
				datauser.put("qtykiloan", String.valueOf((long)(temp)));
				qtykilo.setText(String.valueOf((long)(temp)));
				temp = Double.parseDouble(datauser.get("pricekiloan1").toString()) * temp;
				kiloanprice.setText(String.valueOf((long)(temp)));
				datauser.put("pricekiloan", String.valueOf((long)(temp)));
				datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
				total.setText("Rp. ".concat(datauser.get("totprice").toString()));
			}
		});
		
		jasminus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 == Double.parseDouble(qtyjas.getText().toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "Qty cannot less than 0");
				}
				else {
					temp = Double.parseDouble(qtyjas.getText().toString());
					temp--;
					datauser.put("qtyjas", String.valueOf((long)(temp)));
					qtyjas.setText(String.valueOf((long)(temp)));
					temp = Double.parseDouble(datauser.get("pricejas1").toString()) * temp;
					jasprice.setText(String.valueOf((long)(temp)));
					datauser.put("pricejas", String.valueOf((long)(temp)));
					datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
					total.setText("Rp. ".concat(datauser.get("totprice").toString()));
				}
			}
		});
		
		jasplus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				temp = Double.parseDouble(qtyjas.getText().toString());
				temp++;
				datauser.put("qtyjas", String.valueOf((long)(temp)));
				qtyjas.setText(String.valueOf((long)(temp)));
				temp = Double.parseDouble(datauser.get("pricejas1").toString()) * temp;
				jasprice.setText(String.valueOf((long)(temp)));
				datauser.put("pricejas", String.valueOf((long)(temp)));
				datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
				total.setText("Rp. ".concat(datauser.get("totprice").toString()));
			}
		});
		
		bedmin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (0 == Double.parseDouble(qtybed.getText().toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "Qty cannot less than 0");
				}
				else {
					temp = Double.parseDouble(qtybed.getText().toString());
					temp--;
					datauser.put("qtybed", String.valueOf((long)(temp)));
					qtybed.setText(String.valueOf((long)(temp)));
					temp = Double.parseDouble(datauser.get("pricebed1").toString()) * temp;
					bedprice.setText(String.valueOf((long)(temp)));
					datauser.put("pricebed", String.valueOf((long)(temp)));
					datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
					total.setText("Rp. ".concat(datauser.get("totprice").toString()));
				}
			}
		});
		
		bedplus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				temp = Double.parseDouble(qtybed.getText().toString());
				temp++;
				datauser.put("qtybed", String.valueOf((long)(temp)));
				qtybed.setText(String.valueOf((long)(temp)));
				temp = Double.parseDouble(datauser.get("pricebed1").toString()) * temp;
				bedprice.setText(String.valueOf((long)(temp)));
				datauser.put("pricebed", String.valueOf((long)(temp)));
				datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
				total.setText("Rp. ".concat(datauser.get("totprice").toString()));
			}
		});
		
		savebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if ("0".equals(datauser.get("totprice").toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "You must at least order 1 item!");
				}
				else {
					if ("".equals(alamattxt.getText().toString()) || " ".equals(alamattxt.getText().toString())) {
						SketchwareUtil.showMessage(getApplicationContext(), "Address must be filled.");
					}
					else {
						if (alamattxt.getText().toString().length() < 15) {
							SketchwareUtil.showMessage(getApplicationContext(), "Address must at least 15 characters.");
						}
						else {
							if (receivertxt.getText().toString().length() < 5) {
								SketchwareUtil.showMessage(getApplicationContext(), "Reciever name must at least 5 characters.");
							}
							else {
								datauser.put("address", alamattxt.getText().toString());
								datauser.put("reciever", receivertxt.getText().toString());
								datauser.put("orderid", FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(5)).toUpperCase().concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(0), (int)(9)))).concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(0), (int)(9)))).concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(0), (int)(9))))))));
								datauser.put("proses", "On Pick Up");
								time = Calendar.getInstance();
								datauser.put("date", new SimpleDateFormat("dd/MM/yyyy").format(time.getTime()));
								final AlertDialog dialog2 = new AlertDialog.Builder(AddproductmemberActivity.this).create();
								View inflate = getLayoutInflater().inflate(R.layout.orderadd, null);
								dialog2.setView(inflate);
								dialog2.setTitle("Order");
								TextView total = (TextView) inflate.findViewById(R.id.totalpricetxt);
								Button but1 = (Button) inflate.findViewById(R.id.order);
								Button but2 = (Button) inflate.findViewById(R.id.cancel);
								total.setText("Rp. "+datauser.get("totprice").toString());
								but1.setOnClickListener(new OnClickListener() { public void onClick(View view) {
										
										memberdata.child(datauser.get("orderid").toString()).updateChildren(datauser);
										SketchwareUtil.showMessage(getApplicationContext(), "Thanks for your order.");
										pindah.setClass(getApplicationContext(), HomememberActivity.class);
										startActivity(pindah);
										finish();
									} });
								but2.setOnClickListener(new OnClickListener() { public void onClick(View view) { dialog2.dismiss(); } });
								dialog2.show();
							}
						}
					}
				}
			}
		});
		
		homebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HomememberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		historybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HistorymemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		helpbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HelpmemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		_memberdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		memberdata.addChildEventListener(_memberdata_child_listener);
		
		_pegawaiprice_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pegawaiprice.addChildEventListener(_pegawaiprice_child_listener);
		
		_userauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_userauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_userauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		datauser = new HashMap<>();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		pindah.setClass(getApplicationContext(), HomememberActivity.class);
		startActivity(pindah);
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		pegawaiprice.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				price = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						price.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				pricetemp = new HashMap<>();
				i = 0;
				for(int _repeat13 = 0; _repeat13 < (int)(price.size()); _repeat13++) {
					pricetemp = price.get((int)i);
					if (pricetemp.get("key").toString().equals("Kiloan")) {
						datauser.put("pricekiloan1", pricetemp.get("price").toString());
						kiloanprice.setText(datauser.get("pricekiloan1").toString());
						txt1.setText(pricetemp.get("nama").toString());
					}
					if (pricetemp.get("key").toString().equals("Jas")) {
						datauser.put("pricejas1", pricetemp.get("price").toString());
						jasprice.setText(datauser.get("pricejas1").toString());
						txt2.setText(pricetemp.get("nama").toString());
					}
					if (pricetemp.get("key").toString().equals("Bed Cover")) {
						datauser.put("pricebed1", pricetemp.get("price").toString());
						bedprice.setText(datauser.get("pricebed1").toString());
						txt3.setText(pricetemp.get("nama").toString());
					}
					i++;
				}
				datauser.put("qtykiloan", "1");
				datauser.put("qtyjas", "1");
				datauser.put("qtybed", "1");
				datauser.put("pricekiloan", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan1").toString()) * Double.parseDouble(datauser.get("qtykiloan").toString()))));
				datauser.put("pricejas", String.valueOf((long)(Double.parseDouble(datauser.get("pricejas1").toString()) * Double.parseDouble(datauser.get("qtyjas").toString()))));
				datauser.put("pricebed", String.valueOf((long)(Double.parseDouble(datauser.get("pricebed1").toString()) * Double.parseDouble(datauser.get("qtybed").toString()))));
				datauser.put("totprice", String.valueOf((long)(Double.parseDouble(datauser.get("pricekiloan").toString()) + (Double.parseDouble(datauser.get("pricejas").toString()) + Double.parseDouble(datauser.get("pricebed").toString())))));
				total.setText("Rp. ".concat(datauser.get("totprice").toString()));
				datauser.put("userid", FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(5)).toUpperCase());
				imageview3.getDrawable().setColorFilter(Color.parseColor("#FFD740"), PorterDuff.Mode.SRC_IN);
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
