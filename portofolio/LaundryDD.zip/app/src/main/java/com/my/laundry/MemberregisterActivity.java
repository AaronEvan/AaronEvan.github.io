package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.CompoundButton;

public class MemberregisterActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private boolean veri = false;
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private CheckBox checkbox1;
	private TextView textview1;
	private TextView textview2;
	private EditText memberemail;
	private LinearLayout place_hoder1;
	private EditText memberpw;
	private LinearLayout place_holder2;
	private EditText memberpwulang;
	private LinearLayout linear5;
	private Button loginbtn;
	private LinearLayout linear6;
	private Button registermemberbtn;
	
	private FirebaseAuth firememberauth;
	private OnCompleteListener<AuthResult> _firememberauth_create_user_listener;
	private OnCompleteListener<AuthResult> _firememberauth_sign_in_listener;
	private OnCompleteListener<Void> _firememberauth_reset_password_listener;
	private Intent pindah = new Intent();
	private TimerTask clockregister;
	private AlertDialog.Builder dialog;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.memberregister);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		memberemail = (EditText) findViewById(R.id.memberemail);
		place_hoder1 = (LinearLayout) findViewById(R.id.place_hoder1);
		memberpw = (EditText) findViewById(R.id.memberpw);
		place_holder2 = (LinearLayout) findViewById(R.id.place_holder2);
		memberpwulang = (EditText) findViewById(R.id.memberpwulang);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		loginbtn = (Button) findViewById(R.id.loginbtn);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		registermemberbtn = (Button) findViewById(R.id.registermemberbtn);
		firememberauth = FirebaseAuth.getInstance();
		dialog = new AlertDialog.Builder(this);
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					memberpw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
					
					memberpwulang.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
				}
				else {
					memberpw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
					memberpwulang.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				}
			}
		});
		
		loginbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), MemberloginActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		registermemberbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (memberemail.getText().toString().equals("") || (memberpw.getText().toString().equals("") || memberpwulang.getText().toString().equals(""))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Email or password cannot be empty.");
				}
				else {
					if (memberpw.getText().toString().equals(memberpwulang.getText().toString())) {
						firememberauth.createUserWithEmailAndPassword(memberemail.getText().toString(), memberpw.getText().toString()).addOnCompleteListener(MemberregisterActivity.this, _firememberauth_create_user_listener);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Password and re-password incorrect");
					}
				}
			}
		});
		
		_firememberauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					FirebaseAuth auth = FirebaseAuth.getInstance();
					com.google.firebase.auth.FirebaseUser user = auth.getCurrentUser();
					user.sendEmailVerification().addOnCompleteListener (new
					OnCompleteListener<Void>()
					{ @Override public void onComplete(Task task) {
							if(task.isSuccessful ()) {
								dialog.setMessage("Please check your email to verify your account");
								dialog.setNegativeButton("Okay", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										
									}
								});
								dialog.create().show();
							} else {
							}}});
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Email already registered.");
				}
			}
		};
		
		_firememberauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_firememberauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		pindah.setClass(getApplicationContext(), MemberloginActivity.class);
		startActivity(pindah);
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
