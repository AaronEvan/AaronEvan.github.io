package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import java.util.HashMap;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import android.content.Intent;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.CompoundButton;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MemberloginActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private CheckBox showpassword;
	private TextView lupapassmember;
	private TextView textview2;
	private EditText emailmember;
	private LinearLayout place_hoder1;
	private EditText pwmember;
	private LinearLayout place_holder2;
	private LinearLayout linear5;
	private Button registerbutton;
	private LinearLayout linear6;
	private Button loginbutton;
	
	private DatabaseReference firemember = _firebase.getReference("firemember");
	private ChildEventListener _firemember_child_listener;
	private FirebaseAuth firememberauth;
	private OnCompleteListener<AuthResult> _firememberauth_create_user_listener;
	private OnCompleteListener<AuthResult> _firememberauth_sign_in_listener;
	private OnCompleteListener<Void> _firememberauth_reset_password_listener;
	private StorageReference firememberstorage = _firebase_storage.getReference("firememberstorage");
	private OnCompleteListener<Uri> _firememberstorage_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _firememberstorage_download_success_listener;
	private OnSuccessListener _firememberstorage_delete_success_listener;
	private OnProgressListener _firememberstorage_upload_progress_listener;
	private OnProgressListener _firememberstorage_download_progress_listener;
	private OnFailureListener _firememberstorage_failure_listener;
	private Intent pindah = new Intent();
	private TimerTask timer;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.memberlogin);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		showpassword = (CheckBox) findViewById(R.id.showpassword);
		lupapassmember = (TextView) findViewById(R.id.lupapassmember);
		textview2 = (TextView) findViewById(R.id.textview2);
		emailmember = (EditText) findViewById(R.id.emailmember);
		place_hoder1 = (LinearLayout) findViewById(R.id.place_hoder1);
		pwmember = (EditText) findViewById(R.id.pwmember);
		place_holder2 = (LinearLayout) findViewById(R.id.place_holder2);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		registerbutton = (Button) findViewById(R.id.registerbutton);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		loginbutton = (Button) findViewById(R.id.loginbutton);
		firememberauth = FirebaseAuth.getInstance();
		
		showpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					pwmember.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
				}
				else {
					pwmember.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				}
			}
		});
		
		lupapassmember.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), MemberpwforgotActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		registerbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), MemberregisterActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		loginbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (emailmember.getText().toString().equals("") || "".equals(pwmember.getText().toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "Email or password cannot be empty.");
				}
				else {
					firememberauth.signInWithEmailAndPassword(emailmember.getText().toString().replace(" ", ""), pwmember.getText().toString()).addOnCompleteListener(MemberloginActivity.this, _firememberauth_sign_in_listener);
					SketchwareUtil.showMessage(getApplicationContext(), "Login Process");
				}
			}
		});
		
		_firemember_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		firemember.addChildEventListener(_firemember_child_listener);
		
		_firememberstorage_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_firememberstorage_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_firememberstorage_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_firememberstorage_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_firememberstorage_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_firememberstorage_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_firememberauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_firememberauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					FirebaseAuth auth = FirebaseAuth.getInstance();
					com.google.firebase.auth.FirebaseUser user = auth.getCurrentUser();
					if(user.isEmailVerified()){
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										pindah.setClass(getApplicationContext(), HomememberActivity.class);
										startActivity(pindah);
										SketchwareUtil.showMessage(getApplicationContext(), "Welcome back, ".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(5)).toUpperCase()));
										finish();
									}
								});
							}
						};
						_timer.schedule(timer, (int)(1000));
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Please check your email for verification");
					} 
				}
				else {
					if ("The passw".equals(_errorMessage.substring((int)(0), (int)(9)))) {
						SketchwareUtil.showMessage(getApplicationContext(), "Email or password incorrect.");
					}
					else {
						if ("There is ".equals(_errorMessage.substring((int)(0), (int)(9)))) {
							SketchwareUtil.showMessage(getApplicationContext(), "Email not registered. Please register your email first.");
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
						}
					}
				}
			}
		};
		
		_firememberauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
