package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.AdapterView;

public class HomememberActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> obj = new HashMap<>();
	private double i = 0;
	private double muncul = 0;
	private boolean check = false;
	private double tampilorder = 0;
	private double n = 0;
	
	private ArrayList<HashMap<String, Object>> listorder = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> orderanFiltered = new ArrayList<>();
	
	private LinearLayout linear6;
	private LinearLayout linear23;
	private LinearLayout topheader;
	private LinearLayout banner;
	private LinearLayout body;
	private LinearLayout navbar;
	private LinearLayout linear18;
	private LinearLayout linear10;
	private ImageView imageview1;
	private TextView textview1;
	private ImageView profilebtn;
	private ImageView imagebanner;
	private LinearLayout notfound;
	private LinearLayout listbody;
	private TextView textview26;
	private Button ordernow;
	private TextView textview27;
	private ListView listview1;
	private LinearLayout homebtn;
	private LinearLayout buybtn;
	private LinearLayout historybtn;
	private LinearLayout helpbtn;
	private ImageView imageview2;
	private TextView textview2;
	private ImageView imageview3;
	private TextView textview3;
	private ImageView his;
	private TextView textview25;
	private ImageView imageview5;
	private TextView textview4;
	
	private Intent pindah = new Intent();
	private DatabaseReference memberdata = _firebase.getReference("memberdata");
	private ChildEventListener _memberdata_child_listener;
	private FirebaseAuth memberauth;
	private OnCompleteListener<AuthResult> _memberauth_create_user_listener;
	private OnCompleteListener<AuthResult> _memberauth_sign_in_listener;
	private OnCompleteListener<Void> _memberauth_reset_password_listener;
	private AlertDialog.Builder popup;
	private TimerTask timer;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.homemember);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		topheader = (LinearLayout) findViewById(R.id.topheader);
		banner = (LinearLayout) findViewById(R.id.banner);
		body = (LinearLayout) findViewById(R.id.body);
		navbar = (LinearLayout) findViewById(R.id.navbar);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		profilebtn = (ImageView) findViewById(R.id.profilebtn);
		imagebanner = (ImageView) findViewById(R.id.imagebanner);
		notfound = (LinearLayout) findViewById(R.id.notfound);
		listbody = (LinearLayout) findViewById(R.id.listbody);
		textview26 = (TextView) findViewById(R.id.textview26);
		ordernow = (Button) findViewById(R.id.ordernow);
		textview27 = (TextView) findViewById(R.id.textview27);
		listview1 = (ListView) findViewById(R.id.listview1);
		homebtn = (LinearLayout) findViewById(R.id.homebtn);
		buybtn = (LinearLayout) findViewById(R.id.buybtn);
		historybtn = (LinearLayout) findViewById(R.id.historybtn);
		helpbtn = (LinearLayout) findViewById(R.id.helpbtn);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview3 = (TextView) findViewById(R.id.textview3);
		his = (ImageView) findViewById(R.id.his);
		textview25 = (TextView) findViewById(R.id.textview25);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview4 = (TextView) findViewById(R.id.textview4);
		memberauth = FirebaseAuth.getInstance();
		popup = new AlertDialog.Builder(this);
		
		profilebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), MemberprofileActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		imagebanner.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setAction(Intent.ACTION_VIEW);
				pindah.setData(Uri.parse("https://instagram.com/ddlaundry.official?igshid=1737jblv3725h"));
				pindah.setPackage("com.instagram.android");
				startActivity(pindah);
			}
		});
		
		ordernow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), AddproductmemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				obj = orderanFiltered.get((int)_position);
				final AlertDialog dialog2 = new AlertDialog.Builder(HomememberActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.detailorder, null);
				dialog2.setView(inflate);
				dialog2.setTitle("Detail Order");
				TextView orderid = (TextView) inflate.findViewById(R.id.orderid);
				TextView total = (TextView) inflate.findViewById(R.id.totaltxt);
				TextView address = (TextView) inflate.findViewById(R.id.address);
				TextView recievertxt = (TextView) inflate.findViewById(R.id.recievertxt) ;
				
				TextView date = (TextView) inflate.findViewById(R.id.date);
				TextView process = (TextView) inflate.findViewById(R.id.process);
				TextView qtykilo = (TextView) inflate.findViewById(R.id.qtykilo);
				TextView qtyjas = (TextView) inflate.findViewById(R.id.qtyjas);
				TextView qtybed = (TextView) inflate.findViewById(R.id.qtybed);
				
				TextView pricekilo = (TextView) inflate.findViewById(R.id.pricekilo);
				TextView pricejas = (TextView) inflate.findViewById(R.id.pricejas);
				TextView pricebed = (TextView) inflate.findViewById(R.id.pricebed);
				
				LinearLayout kilo = (LinearLayout) inflate.findViewById(R.id.kilo);
				LinearLayout jas = (LinearLayout) inflate.findViewById(R.id.jas);
				LinearLayout bed = (LinearLayout) inflate.findViewById(R.id.bed);
				
				Button but1 = (Button) inflate.findViewById(R.id.cancel);
				
				total.setText("Total : Rp. "+obj.get("totprice").toString());
				orderid.setText("Order ID :  "+obj.get("orderid"));
				address.setText("Address :  "+obj.get("address"));
				date.setText("Date Order :  "+obj.get("date"));
				process.setText("Process Status :  "+obj.get("proses"));
				
				recievertxt.setText("Reciever Name :  "+obj.get("reciever"));
				
				qtykilo.setText(obj.get("qtykiloan")+ "kg");
				qtyjas.setText(obj.get("qtyjas")+ "pcs");
				qtybed.setText(obj.get("qtybed")+ "pcs");
				
				pricekilo.setText("Rp. " + obj.get("pricekiloan"));
				pricejas.setText("Rp. " + obj.get("pricejas"));
				pricebed.setText("Rp. " + obj.get("pricebed"));
				if (!(Double.parseDouble(obj.get("qtykiloan").toString()) > 0)) {
					kilo.setVisibility(View.GONE);
				}
				if (!(Double.parseDouble(obj.get("qtyjas").toString()) > 0)) {
					jas.setVisibility(View.GONE);
				}
				if (!(Double.parseDouble(obj.get("qtybed").toString()) > 0)) {
					bed.setVisibility(View.GONE);
				}
				but1.setOnClickListener(new OnClickListener() { public void onClick(View view) { dialog2.dismiss(); } });
				dialog2.show();
			}
		});
		
		buybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), AddproductmemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		historybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HistorymemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		helpbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HelpmemberActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		_memberdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		memberdata.addChildEventListener(_memberdata_child_listener);
		
		_memberauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		notfound.setVisibility(View.INVISIBLE);
		listbody.setVisibility(View.INVISIBLE);
		obj = new HashMap<>();
		memberdata.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				listorder = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						listorder.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				i = 0;
				for(int _repeat18 = 0; _repeat18 < (int)(listorder.size()); _repeat18++) {
					obj = listorder.get((int)i);
					if (obj.get("userid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid().substring((int)(0), (int)(5)).toUpperCase())) {
						if (!obj.get("proses").toString().equals("Finished")) {
							orderanFiltered.add(obj);
							tampilorder = 1;
						}
						else {
							
						}
					}
					i++;
				}
				listview1.setAdapter(new Listview1Adapter(orderanFiltered));
				if (1 == tampilorder) {
					notfound.setVisibility(View.GONE);
					listbody.setVisibility(View.VISIBLE);
				}
				else {
					notfound.setVisibility(View.VISIBLE);
					listbody.setVisibility(View.INVISIBLE);
				}
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		obj.clear();
		imageview2.getDrawable().setColorFilter(Color.parseColor("#FFD740"), PorterDuff.Mode.SRC_IN);
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						n++;
						if (n == 1) {
							imagebanner.setImageResource(R.drawable.banner2);
						}
						if (n == 2) {
							imagebanner.setImageResource(R.drawable.banner1);
							n = 0;
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(2000), (int)(4800));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		popup.setTitle("Exit?");
		popup.setMessage("Do you want to exit? ");
		popup.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		popup.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		popup.create().show();
	}
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.listview, null);
			}
			
			final LinearLayout full = (LinearLayout) _v.findViewById(R.id.full);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final TextView orderid = (TextView) _v.findViewById(R.id.orderid);
			final TextView pricetot = (TextView) _v.findViewById(R.id.pricetot);
			final TextView datetxt = (TextView) _v.findViewById(R.id.datetxt);
			final TextView statustxt = (TextView) _v.findViewById(R.id.statustxt);
			
			obj = new HashMap<>();
			obj = orderanFiltered.get((int)_position);
			if ("On Pick Up".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#E57373"));
			}
			if ("On Laundry".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#FFD740"));
			}
			if ("On Delivery".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#7CB342"));
			}
			orderid.setText(obj.get("orderid").toString());
			pricetot.setText("Rp. ".concat(obj.get("totprice").toString()));
			datetxt.setText(obj.get("date").toString());
			statustxt.setText("Status : ".concat(obj.get("proses").toString()));
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
