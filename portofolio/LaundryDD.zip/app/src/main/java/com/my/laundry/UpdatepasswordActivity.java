package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;

public class UpdatepasswordActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> obj = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear23;
	private LinearLayout topheader;
	private LinearLayout body;
	private LinearLayout navbar;
	private LinearLayout linear18;
	private LinearLayout linear10;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout listbody;
	private TextView textview27;
	private TextView textview29;
	private EditText oldtxt;
	private TextView textview28;
	private EditText pass;
	private TextView textview30;
	private EditText repass;
	private Button changebtn;
	private LinearLayout homebtn;
	private LinearLayout buybtn;
	private LinearLayout historybtn;
	private LinearLayout helpbtn;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private ImageView imageview4;
	private TextView textview25;
	private ImageView now;
	private TextView textview5;
	
	private Intent pindah = new Intent();
	private DatabaseReference pegawaidb = _firebase.getReference("pegawai");
	private ChildEventListener _pegawaidb_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.updatepassword);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		topheader = (LinearLayout) findViewById(R.id.topheader);
		body = (LinearLayout) findViewById(R.id.body);
		navbar = (LinearLayout) findViewById(R.id.navbar);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		listbody = (LinearLayout) findViewById(R.id.listbody);
		textview27 = (TextView) findViewById(R.id.textview27);
		textview29 = (TextView) findViewById(R.id.textview29);
		oldtxt = (EditText) findViewById(R.id.oldtxt);
		textview28 = (TextView) findViewById(R.id.textview28);
		pass = (EditText) findViewById(R.id.pass);
		textview30 = (TextView) findViewById(R.id.textview30);
		repass = (EditText) findViewById(R.id.repass);
		changebtn = (Button) findViewById(R.id.changebtn);
		homebtn = (LinearLayout) findViewById(R.id.homebtn);
		buybtn = (LinearLayout) findViewById(R.id.buybtn);
		historybtn = (LinearLayout) findViewById(R.id.historybtn);
		helpbtn = (LinearLayout) findViewById(R.id.helpbtn);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview25 = (TextView) findViewById(R.id.textview25);
		now = (ImageView) findViewById(R.id.now);
		textview5 = (TextView) findViewById(R.id.textview5);
		
		changebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if ("".equals(oldtxt.getText().toString()) || ("".equals(pass.getText().toString()) || "".equals(repass.getText().toString()))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Old /New / Re Password cannot be empty. ");
				}
				else {
					if (!pass.getText().toString().equals(repass.getText().toString())) {
						SketchwareUtil.showMessage(getApplicationContext(), "New and Re Password not match. ");
					}
					else {
						pegawaidb.addListenerForSingleValueEvent(new ValueEventListener() {
							@Override
							public void onDataChange(DataSnapshot _dataSnapshot) {
								list = new ArrayList<>();
								try {
									GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
									for (DataSnapshot _data : _dataSnapshot.getChildren()) {
										HashMap<String, Object> _map = _data.getValue(_ind);
										list.add(_map);
									}
								}
								catch (Exception _e) {
									_e.printStackTrace();
								}
								if (!oldtxt.getText().toString().equals(list.get((int)0).get("password").toString())) {
									SketchwareUtil.showMessage(getApplicationContext(), "Old password is incorrect.");
								}
								else {
									SketchwareUtil.showMessage(getApplicationContext(), "Password successfully changed.");
									obj = new HashMap<>();
									obj.put("password", pass.getText().toString());
									obj.put("username", "admin");
									pegawaidb.child("admin").updateChildren(obj);
									pindah.setClass(getApplicationContext(), HomepegawaiActivity.class);
									startActivity(pindah);
									finish();
								}
							}
							@Override
							public void onCancelled(DatabaseError _databaseError) {
							}
						});
					}
				}
			}
		});
		
		homebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HomepegawaiActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		buybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), PricepegawaiActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		historybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HistorypegawaiActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		_pegawaidb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pegawaidb.addChildEventListener(_pegawaidb_child_listener);
	}
	private void initializeLogic() {
		now.getDrawable().setColorFilter(Color.parseColor("#FFD740"), PorterDuff.Mode.SRC_IN);
		imageview2.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
		imageview3.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
		imageview4.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		pindah.setClass(getApplicationContext(), HomepegawaiActivity.class);
		startActivity(pindah);
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
