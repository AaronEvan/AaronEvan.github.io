package com.my.laundry;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.AdapterView;
import android.view.View;

public class HomepegawaiActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> obj = new HashMap<>();
	private double checkorder = 0;
	private double i = 0;
	
	private ArrayList<HashMap<String, Object>> order = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear23;
	private LinearLayout topheader;
	private LinearLayout body;
	private LinearLayout navbar;
	private LinearLayout linear18;
	private LinearLayout linear10;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout notfound;
	private LinearLayout listbody;
	private TextView textview26;
	private ListView listview1;
	private LinearLayout homebtn;
	private LinearLayout buybtn;
	private LinearLayout historybtn;
	private LinearLayout helpbtn;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private ImageView imageview4;
	private TextView textview25;
	private ImageView imageview5;
	private TextView textview5;
	
	private DatabaseReference memberdata = _firebase.getReference("memberdata");
	private ChildEventListener _memberdata_child_listener;
	private Intent pindah = new Intent();
	private FirebaseAuth memberauth;
	private OnCompleteListener<AuthResult> _memberauth_create_user_listener;
	private OnCompleteListener<AuthResult> _memberauth_sign_in_listener;
	private OnCompleteListener<Void> _memberauth_reset_password_listener;
	private AlertDialog.Builder popup;
	private TimerTask timer;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.homepegawai);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		topheader = (LinearLayout) findViewById(R.id.topheader);
		body = (LinearLayout) findViewById(R.id.body);
		navbar = (LinearLayout) findViewById(R.id.navbar);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		notfound = (LinearLayout) findViewById(R.id.notfound);
		listbody = (LinearLayout) findViewById(R.id.listbody);
		textview26 = (TextView) findViewById(R.id.textview26);
		listview1 = (ListView) findViewById(R.id.listview1);
		homebtn = (LinearLayout) findViewById(R.id.homebtn);
		buybtn = (LinearLayout) findViewById(R.id.buybtn);
		historybtn = (LinearLayout) findViewById(R.id.historybtn);
		helpbtn = (LinearLayout) findViewById(R.id.helpbtn);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview25 = (TextView) findViewById(R.id.textview25);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview5 = (TextView) findViewById(R.id.textview5);
		memberauth = FirebaseAuth.getInstance();
		popup = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				obj = order.get((int)_position);
				final AlertDialog dialog2 = new AlertDialog.Builder(HomepegawaiActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.detailorder, null);
				dialog2.setView(inflate);
				dialog2.setTitle("Detail Order");
				TextView orderid = (TextView) inflate.findViewById(R.id.orderid);
				TextView total = (TextView) inflate.findViewById(R.id.totaltxt);
				TextView address = (TextView) inflate.findViewById(R.id.address);
				TextView date = (TextView) inflate.findViewById(R.id.date);
				TextView process = (TextView) inflate.findViewById(R.id.process);
				TextView qtykilo = (TextView) inflate.findViewById(R.id.qtykilo);
				TextView qtyjas = (TextView) inflate.findViewById(R.id.qtyjas);
				TextView qtybed = (TextView) inflate.findViewById(R.id.qtybed);
				
				TextView pricekilo = (TextView) inflate.findViewById(R.id.pricekilo);
				TextView pricejas = (TextView) inflate.findViewById(R.id.pricejas);
				TextView pricebed = (TextView) inflate.findViewById(R.id.pricebed);
				
				TextView recievertxt = (TextView) inflate.findViewById(R.id.recievertxt) ;
				recievertxt.setText("Reciever Name :  "+obj.get("reciever"));
				
				LinearLayout kilo = (LinearLayout) inflate.findViewById(R.id.kilo);
				LinearLayout jas = (LinearLayout) inflate.findViewById(R.id.jas);
				LinearLayout bed = (LinearLayout) inflate.findViewById(R.id.bed);
				
				Button but1 = (Button) inflate.findViewById(R.id.cancel);
				
				total.setText("Total : Rp. "+obj.get("totprice").toString());
				orderid.setText("Order ID :  "+obj.get("orderid"));
				address.setText("Address :  "+obj.get("address"));
				date.setText("Date Order :  "+obj.get("date"));
				process.setText("Process Status :  "+obj.get("proses"));
				
				qtykilo.setText(obj.get("qtykiloan")+ "kg");
				qtyjas.setText(obj.get("qtyjas")+ "pcs");
				qtybed.setText(obj.get("qtybed")+ "pcs");
				
				pricekilo.setText("Rp. " + obj.get("pricekiloan"));
				pricejas.setText("Rp. " + obj.get("pricejas"));
				pricebed.setText("Rp. " + obj.get("pricebed"));
				if (!(Double.parseDouble(obj.get("qtykiloan").toString()) > 0)) {
					kilo.setVisibility(View.GONE);
				}
				if (!(Double.parseDouble(obj.get("qtyjas").toString()) > 0)) {
					jas.setVisibility(View.GONE);
				}
				if (!(Double.parseDouble(obj.get("qtybed").toString()) > 0)) {
					bed.setVisibility(View.GONE);
				}
				but1.setOnClickListener(new OnClickListener() { public void onClick(View view) { dialog2.dismiss(); } });
				dialog2.show();
			}
		});
		
		buybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), PricepegawaiActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		historybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), HistorypegawaiActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		helpbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				pindah.setClass(getApplicationContext(), UpdatepasswordActivity.class);
				startActivity(pindah);
				finish();
			}
		});
		
		_memberdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				order.clear();
				notfound.setVisibility(View.INVISIBLE);
				listbody.setVisibility(View.INVISIBLE);
				checkorder = 0;
				obj = new HashMap<>();
				memberdata.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						list = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								list.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						i = 0;
						for(int _repeat38 = 0; _repeat38 < (int)(list.size()); _repeat38++) {
							obj = list.get((int)i);
							if (!obj.get("proses").toString().equals("Finished")) {
								order.add(obj);
								checkorder = 1;
							}
							else {
								
							}
							i++;
						}
						listview1.setAdapter(new Listview1Adapter(order));
						if (1 == checkorder) {
							notfound.setVisibility(View.GONE);
							listbody.setVisibility(View.VISIBLE);
						}
						else {
							notfound.setVisibility(View.VISIBLE);
							listbody.setVisibility(View.INVISIBLE);
						}
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
				obj.clear();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		memberdata.addChildEventListener(_memberdata_child_listener);
		
		_memberauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_memberauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		notfound.setVisibility(View.INVISIBLE);
		listbody.setVisibility(View.INVISIBLE);
		checkorder = 0;
		obj = new HashMap<>();
		memberdata.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				list = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						list.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				i = 0;
				for(int _repeat21 = 0; _repeat21 < (int)(list.size()); _repeat21++) {
					obj = list.get((int)i);
					if (!obj.get("proses").toString().equals("Finished")) {
						order.add(obj);
						checkorder = 1;
					}
					else {
						
					}
					i++;
				}
				listview1.setAdapter(new Listview1Adapter(order));
				if (1 == checkorder) {
					notfound.setVisibility(View.GONE);
					listbody.setVisibility(View.VISIBLE);
				}
				else {
					notfound.setVisibility(View.VISIBLE);
					listbody.setVisibility(View.INVISIBLE);
				}
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		obj.clear();
		imageview2.getDrawable().setColorFilter(Color.parseColor("#FFD740"), PorterDuff.Mode.SRC_IN);
		imageview5.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
		imageview3.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
		imageview4.getDrawable().setColorFilter(Color.parseColor("#6D7A80"), PorterDuff.Mode.SRC_IN);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		popup.setTitle("Exit?");
		popup.setMessage("Do you want to exit? ");
		popup.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		popup.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		popup.create().show();
	}
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.orderlist, null);
			}
			
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final LinearLayout linear6 = (LinearLayout) _v.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _v.findViewById(R.id.linear8);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final LinearLayout linear7 = (LinearLayout) _v.findViewById(R.id.linear7);
			final TextView orderid = (TextView) _v.findViewById(R.id.orderid);
			final TextView pricetot = (TextView) _v.findViewById(R.id.pricetot);
			final TextView datetxt = (TextView) _v.findViewById(R.id.datetxt);
			final TextView statustxt = (TextView) _v.findViewById(R.id.statustxt);
			final Switch laundry = (Switch) _v.findViewById(R.id.laundry);
			final Switch delivery = (Switch) _v.findViewById(R.id.delivery);
			final Switch finished = (Switch) _v.findViewById(R.id.finished);
			
			obj = new HashMap<>();
			obj = order.get((int)_position);
			laundry.setVisibility(View.GONE);
			finished.setVisibility(View.GONE);
			delivery.setVisibility(View.GONE);
			if ("On Pick Up".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#E57373"));
				laundry.setVisibility(View.VISIBLE);
			}
			if ("On Laundry".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#FFD740"));
				delivery.setVisibility(View.VISIBLE);
			}
			if ("On Delivery".equals(obj.get("proses").toString())) {
				orderid.setBackgroundColor(Color.parseColor("#7CB342"));
				finished.setVisibility(View.VISIBLE);
			}
			orderid.setText(obj.get("orderid").toString());
			pricetot.setText("Rp. ".concat(obj.get("totprice").toString()));
			datetxt.setText(obj.get("date").toString());
			statustxt.setText("Status : ".concat(obj.get("proses").toString()));
			laundry.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					obj = new HashMap<>();
					obj = order.get((int)_position);
					popup.setTitle("Change Status");
					popup.setMessage("Do sure want to change the order status? ");
					popup.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							laundry.setChecked(true);
							laundry.setVisibility(View.GONE);
							obj.remove("proses");
							obj.put("proses", "On Laundry");
							memberdata.child(obj.get("orderid").toString()).updateChildren(obj);
						}
					});
					popup.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							laundry.setChecked(false);
						}
					});
					popup.create().show();
				}
			});
			delivery.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					obj = new HashMap<>();
					obj = order.get((int)_position);
					popup.setTitle("Change Status");
					popup.setMessage("Do sure want to change the order status? ");
					popup.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							delivery.setChecked(true);
							delivery.setVisibility(View.GONE);
							obj.remove("proses");
							obj.put("proses", "On Delivery");
							memberdata.child(obj.get("orderid").toString()).updateChildren(obj);
						}
					});
					popup.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							delivery.setChecked(false);
						}
					});
					popup.create().show();
				}
			});
			finished.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					obj = new HashMap<>();
					obj = order.get((int)_position);
					popup.setTitle("Change Status");
					popup.setMessage("Do sure want to change the order status? ");
					popup.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finished.setChecked(true);
							finished.setVisibility(View.GONE);
							obj.remove("proses");
							obj.put("proses", "Finished");
							memberdata.child(obj.get("orderid").toString()).updateChildren(obj);
						}
					});
					popup.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							finished.setChecked(false);
						}
					});
					popup.create().show();
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
